
package homework1;

import java.awt.*;

/**
 * An AngleChangingSector is a Shape that can change its angle using its step()
 * method. An AngleChangingSector has a start angle and arc angle properties that determine the sector itself
 * and its angle regarding the bounding rectangle's lowest bound.
 */
public class AngleChangingSector extends homework1.Shape implements homework1.Animatable {
    Dimension dim;
    int startAngle;
    int arcAngle;

    // Abstraction Function:
    // startAngle = first bound of sector
    // second bound of sector(counter clockwise) = startAngle + arcAngle

    // Representation Invariant:
    // this.startAngle != null
    // this.arcAngle != null
    // dim.height >= 0
    // dim.width >= 0

    /**
     * @requires - valid dimension (>=0)
     * @effects  - initializes this
     */
    public AngleChangingSector(Point location, Color color, Dimension dimension, int startAngle_, int arcAngle_) {
        super(location, color);
        this.dim = dimension;
        this.startAngle = startAngle_;
        this.arcAngle = arcAngle_;
        this.checkRep();
    }

    /**
     * @modifies - this
     * @effects - increments lower bound of the sector by 1 each step.
     */
    @Override
    public void step(Rectangle bound) {
        this.startAngle++;
    }

    /**
     * @requires - valid dimensions (>0)
     * @modifies - this
     * @effects  - sets this angle changing sector with new size
     * @param 	 - dimension =
     *             Dimension instance which holds height and width of the desired new bounding rectangle's size
     */
    @Override
    public void setSize(Dimension dimension) throws homework1.ImpossibleSizeException {
        this.checkRep();
        if(dimension.getHeight() < 0 || dimension.getWidth() < 0){
            throw new homework1.ImpossibleSizeException(dimension);
        }
        this.dim = dimension;
        this.checkRep();
    }

    /**
     * @return 	 - this shape's bounding rectangle
     */
    @Override
    public Rectangle getBounds() {
        this.checkRep();
        return new Rectangle(super.getLocation(),this.dim);
    }

    /**
     * @requires - non null Graphics reference (g)
     * @modifies - g
     * @effects  - draws an oval equivalent to this angle changing sector's representation on the graphic component
     * @param 	 - g = graphic component of type Graphics
     */
    @Override
    public void draw(Graphics g) {
        this.checkRep();
        g.setColor(super.getColor());
        g.fillArc(super.getLocation().x, super.getLocation().y, this.dim.width,
                    this.dim.height, this.startAngle, this.arcAngle);
    }

    /**
     * @effects throws alerts on different assertions of the Representation Invariant
     * @throws AssertionError if the Representation Invariant is being violated.
     */
    private void checkRep() {
        assert this.dim != null : "Dimension of an angle changing sector can never be null";
        assert this.dim.height >= 0 : "Height of an angle changing sector can never be < 0";
        assert this.dim.width >= 0 : "Width of an angle changing sector can never be < 0";    }
}
