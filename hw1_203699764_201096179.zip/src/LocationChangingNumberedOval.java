
package homework1;

import java.awt.*;

/**
 * A LocationChangingNumberedOval is a LocationChangingOval. A LocationChangingNumberedOval has its ID which is its
 * chronological index of creation amongst the other numbered instances.
 * a LocationChangingOval needs to be initiated with valid dimensions which can be changed later.
 */
public class LocationChangingNumberedOval extends LocationChangingOval {
    static int totalNumOfNumberedOvals;
    private Integer selfId;

    // Abstraction Function:
    // number of oval = selfId

    // Representation Invariant:
    // this.selfId > 0

    /**
     * @requires - valid dimension (>=0)
     * @effects  - initializes this
     */
    LocationChangingNumberedOval(Point location, Color color, Dimension dimension) {
        super(location, color, dimension);
        this.incrementNumOfNumberedOvals();
        selfId = totalNumOfNumberedOvals;
        checkRep();
    }

    /**
    * @effects  - increments total static count of numbered ovals
    */
    private void incrementNumOfNumberedOvals() {
    	LocationChangingNumberedOval.totalNumOfNumberedOvals ++;
    }

    /**
     * @effects  - resets total static count of numbered ovals to zero
     */
    public static void zeroNumberOfNumberedOvals() {
    	LocationChangingNumberedOval.totalNumOfNumberedOvals = 0;
    }

    /**
     * @requires - non null Graphics reference (g)
     * @modifies - g
     * @effects  - draws an oval equivalent to this numbered oval's representation on the graphic component
     * @param 	 - g = graphic component of type Graphics
     */
    public void draw(Graphics g) {
        this.checkRep();
        g.setColor(super.getColor());
        g.fillOval(super.getLocation().x, super.getLocation().y,super.getBounds().width, super.getBounds().height);
        g.setColor(java.awt.Color.black);
        g.drawString( selfId.toString(), super.getLocation().x, super.getLocation().y);
    }

    /**
     * @effects throws alerts on different assertions of the Representation Invariant
     * @throws AssertionError if the Representation Invariant is being violated.
     */
    private void checkRep() {
    	assert selfId.intValue() > 0 : "Oval's ID number can never be <= 0";
    }
}
