
package homework1;

import java.awt.*;

/**
 * A LocationChangingRoundedRectangle is a LocationChangingRectangle.
 * A LocationChangingRoundedRectangle has its rounded corners dimensions.
 * A LocationChangingRectangle needs to be initiated with valid dimensions(bounding rect) which can be changed later.
 */
public class LocationChangingRoundedRectangle extends LocationChangingRectangle {
	int arcWidth;
	int arcHeight;

    // Abstraction Function:
    // distance from the right and left bounds where it starts to get rounded = arcWidth
    // distance from the upper and lower bounds where it starts to get rounded = arcHeight

    // Representation Invariant:
    // dim != null
    // arcWidth >= 0
    // arcHeight >= 0

    /**
     * @effects  -initializes this
     * @param 	 - location = the down left corner of the bounding rect, color = shape's color,
     * dimension = height and width of bounding rect, arcWidth_/arcHeight_ = proportions of the rounds
     */
    LocationChangingRoundedRectangle(Point location, Color color,Dimension dimension, int arcWidth_, int arcHeight_) {
        super(location, color, dimension);
        this.arcWidth = arcWidth_;
        this.arcHeight = arcHeight_;
    }

    /**
     * @requires - non null Graphics reference (g)
     * @modifies - g
     * @effects  - draws a rounded rectangle equivalent to this rounded rectangle representation
     *             on the graphic component
     * @param 	 - g = graphic component of type Graphics
     */
    public void draw(Graphics g) {
        this.checkRep();
        g.setColor(super.getColor());
        g.fillRoundRect(super.getLocation().x, super.getLocation().y, super.getBounds().width,
                        super.getBounds().height, this.arcWidth, this.arcHeight);
    }

    /**
     * @effects throws alerts on different assertions of the Representation Invariant
     * @throws AssertionError if the Representation Invariant is being violated.
     */
    private void checkRep() {
    	assert arcWidth >= 0 : "Arc width of a rounded rectangle can never be < 0";
    	assert arcHeight >= 0 : "Arc height of a rounded rectangle can never be < 0";
    }
    
}
