
package homework1;

import java.awt.*;


/**
 * A LocationChangingRectangle is a LocationChangingShape. A LocationChangingRectangle has a rectangle representation
 * which is implemented using Dimension. a LocationChangingRectangle needs to be initiated with valid dimensions
 * which can be changed later.
 */
public class LocationChangingRectangle extends homework1.LocationChangingShape {
    private Dimension dim;
    private int height;
    private int width;
    // Abstraction Function:
    // width of rectangle = dim.Width
    // Height of rectangle = dim.Height

    // Representation Invariant:
    // dim != null
    // dim.Height >= 0
    // dim.Width >= 0
    /**
     * @requires - valid dimension (>=0)
     * @effects  - initializes this
     */
    LocationChangingRectangle(Point location, Color color, Dimension dimension) {
        super(location, color);
        this.dim = dimension;
    }

    /**
     * @requires - valid dimensions (>0)
     * @modifies - this
     * @effects  - sets this rectangle with new size
     * @param 	 - dimension = Dimension instance which holds height and width of the desired new size
     */
    @Override
    public void setSize(Dimension dimension) throws homework1.ImpossibleSizeException {
        this.checkRep();
        if(dimension.getHeight() < 0 || dimension.getWidth() < 0){
            throw new homework1.ImpossibleSizeException(dimension);
        }
        this.dim = dimension;
        this.checkRep();
        return;
    }

    /**
     * @return 	 - this shape's bounding rectangle
     */
    @Override
    public Rectangle getBounds() {
        checkRep();
        return new Rectangle(super.getLocation(),this.dim);
    }

    /**
     * @requires - non null Graphics reference (g)
     * @modifies - g
     * @effects  - draws a rectangle equivalent to this rectangle representation on the graphic component
     * @param 	 - g = graphic component of type Graphics
     */
    @Override
    public void draw(Graphics g) {
        this.checkRep();
        if(g == null){
            return;
        }
        g.setColor(super.getColor());
        g.fillRect(super.getLocation().x, super.getLocation().y, this.dim.width, this.dim.height);
    }

    /**
     * @effects throws alerts on different assertions of the Representation Invariant
     * @throws AssertionError if the Representation Invariant is being violated.
     */
    private void checkRep() {
        assert this.dim != null : "Dimension of a rectangle can never be null";
        assert this.dim.height >= 0 : "Height of a rectangle can never be < 0";
        assert this.dim.width >= 0 : "Width of a rectangle can never be < 0";
    }
}
